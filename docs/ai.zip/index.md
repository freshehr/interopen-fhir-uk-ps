# Home - UK Patient Summary Implementation Guide v0.1.0-cibuild

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org.uk/fhir/ps/ImplementationGuide/hl7.fhir.uk.ps | *Version*:0.1.0-cibuild | |
| * IG Standards status: *[Draft](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](https://build.fhir.org/ig/hl7au/au-fhir-base/generalguidance.html#maturity-levels): 1 | *Computable Name*:UKPatientSummaryImplementationGuide |
| **Copyright/Legal**: Used by permission of HL7 International, all rights reserved Creative Commons License. HL7 UK© 2025+; Licensed Under Creative Commons No Rights Reserved. | | |

### Introduction

UK Patient Summary (UK PS) is provided to support the use of patient summaries in HL7® FHIR®© in an UK context. UK PS is based on [IPS](https://hl7.org/fhir/uv/ips/STU2/index.html) and [UK Core STU2](https://simplifier.net/guide/uk-core-implementation-guide-stu2?version=2.0.1), setting the minimum conformance expectations for implementing support for UK PS documents in systems.

UK PS is compliant with the requirements of IPS, e.g. UK PS data is conformant to IPS and systems that generate and consume UK PS documents are conformant to the requirements in IPS:

* A valid UK PS document IS a valid IPS document - the document instance validates against both IGs.
* A conformant UK PS actor IS a conformant IPS actor - the conformance expectations for implementation for IPS are satisfied when implementing UK PS actor requirements.

For a detailed description of the requirements for implementing UK PS, see the [General Requirements](general-requirements.md#general-requirements) page.

A Patient Summary is:

* a health record extract comprising a core set of digital health and administrative data elements that provide a snapshot in time of a subject of care’s health information and healthcare.
* designed for supporting use case scenarios including planned and unplanned care, continuity of care and transition of care.

See [The UK PS](the-ukps.md) for more information on the purpose, scope, context, and use of UK PS.

### Dependencies





* Parameter: system-version
  * Value: SNOMED CT[AU]

### How to Read This Guide

This guide is divided into several pages which are listed at the top of each page in the menu bar.

* [Home](index.md): This page provides the introduction and scope for this guide.
* [Conformance](conformance.md): These pages describe the set of rules to claim conformance to this guide including the expectations for **Must Support** elements in UK PS profiles. 
* [General Requirements](general-requirements.md): This page defines requirements common to profiles used in this guide including the expectations for mandatory and **Must Support** elements in UK PS profiles.
* [Declaring Conformance](declaring-conformance.md): This page describes how to declare conformance to UK PS.
 
* [The UK PS](the-ukps.md): This page describes the UK PS including structure, context of use, and localisation of the IPS.
* [Guidance](guidance.md): These pages list the guidance for this guide. 
* [General Guidance](general-guidance.md): This page provides guidance on using the profiles defined in this guide.
* [Generation and Access](generation-and-access.md): This page describes some options for generation and access of patient summary documents.
* [UK Variance Statement](variance.md): This page documents the variance from UK Base and UK Core.
* [Comparison With Other National and International IGs](comparison.md): This page provides comparison between UK PS profiles and other national and international implementation guides.
 
* [Use Cases](usecase.md): These pages document a set of example use cases that assist in understanding how to implement UK PS. 
* [Cross-regional Unscheduled care](uc-interstate.md): This page documents use of the Patient Summary when a patient is not in their home locality.
* [Cross-national Unscheduled care](uc-interstate.md): This page documents use of the Patient Summary when a patient is not in their home country.
* [Cross-regional Scheduled care](uc-interstate.md): This page documents use of the Patient Summary when a patient is receiving scheduled care but not in their in their home locality.
 
* [Security and Privacy](security.md): This page documents the UK PS general security and privacy requirements and recommendations.
* [FHIR Artefacts](artefacts.md): These pages provide detailed descriptions and formal definitions for all the FHIR artefacts defined in this guide. 
* [Artefacts Summary](artifacts.md): This page lists the FHIR artefacts defined in this guide.
* [Profiles and Extensions](profiles-and-extensions.md): This page describes the profiles and extensions that are defined in this guide to exchange data. Each profile page includes a narrative description and guidance, and formal definition. Guidance typically focuses on the profiled elements but can include guidance on un-profiled elements to aid with implementation.
* [Terminology](terminology.md): This page lists the value sets and code systems supported in this guide.
* [Actor Definitions](actors.md): This page defines the UK PS actors, UK PS Consumer and UK PS Producer.
 
* [Examples](examples.md): This page lists all the examples used in this guide.
* [Support](downloads.md): These pages provide supporting material for implementation of UK PS. 
* [Downloads](downloads.md): This page provides links to downloadable artefacts.
* [License and Legal](license.md): This page outlines the license and legal requirements for material in UK PS.
 
* [Change Log](changes.md): This page documents the changes across versions of this guide.

### Collaboration

This guide is the product of collaborative work undertaken with participants from: Primary Editors: .

